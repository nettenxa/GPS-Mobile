# Android_Location_Demo
Android_Location_Demo

How to Get Latitude and Longitude from Android Device Tutorial
In This Tutorial I Cover: 
1. How to Get Latitude and Longitude from Android Device
2. How to Get Runtime Location Permission
3. Android Multiple Permission
4. Android Location Tutorial

<br>
<h3>Added Google Map With Current Location Marker</h3>
<br>
<h3>Added Google Play Service Location Api with Map</h3>
